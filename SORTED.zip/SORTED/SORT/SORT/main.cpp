#include"sort.h"
int main() {
    cout << "- Reading file Books_rating.csv in chunks....\n";
    fstream fin;
    fin.open("Books_rating.csv", ios::in | ios::binary);
    int chunkSize = 200000000; // bytes
    int numFile = readFileInChunk(fin, chunkSize);
    fin.close();
    cout << "- Merging " << numFile << " sorted files....\n";
    mergeFile(numFile);
    cout << "   + File 'sorted_books_rating.csv' was created successfully !!!\n";
    return 0;
}