#include<iostream>
#include <string> 
#include <fstream>
#include <vector>
#include <sstream>
#include <queue>
using namespace std;
string getIdBook(string& row);
struct minHeapNode;
struct compare;
void mergeFile(int numFile);
int partition(vector<string>& data, int l, int r);
void quickSort(vector<string>& data, int l, int r);
void sortAndWrite(vector<string>& data, int numFile);
int readFileInChunk(fstream& fin, int chunkSize);
